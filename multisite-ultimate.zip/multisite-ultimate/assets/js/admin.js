/* global wu_on_load */
(function($) {

  // eslint-disable-next-line no-undef
  wu = {
    tables: {},
    configs: {},
  };

  $(document).ready(function() {

    wu_on_load();

  });

}(jQuery));
